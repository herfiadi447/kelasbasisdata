from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import folium
import geopandas as gpd
import os

app = Flask(__name__)

# Konfigurasi folder untuk menyimpan file zip yang diupload
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def tampilkan_peta():
    # Render tampilan awal
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    # Cek apakah ada file yang di-upload oleh user
    if 'file' not in request.files:
        return {"error": "Tidak ada file yang diunggah"}, 400
        
    file = request.files['file']
    
    if file and file.filename.endswith('.zip'):
        # Amankan nama file dan simpan ke folder uploads
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        try:
            # GeoPandas membaca file zip SHP secara langsung!
            gdf = gpd.read_file(f"zip://{filepath}")
            
            # WAJIB: Konversi proyeksi ke EPSG:4326 (WGS84 / LatLon) agar terbaca di WebGIS
            if gdf.crs is None:
                gdf.set_crs(epsg=4326, inplace=True)
            elif gdf.crs != "EPSG:4326":
                gdf = gdf.to_crs(epsg=4326)
            
            # Konversi GeoDataFrame menjadi format GeoJSON
            geojson_data = gdf.to_json()
            
            # Hapus file setelah diproses agar tidak menumpuk
            if os.path.exists(filepath):
                os.remove(filepath)
            
            # Mengembalikan response dalam bentuk JSON agar diproses oleh script.js  
            return geojson_data
            
        except Exception as e:
            if os.path.exists(filepath):
                os.remove(filepath)
            return {"error": f"Terjadi kesalahan saat membaca file: {str(e)}"}, 500
            
    return {"error": "Format file tidak valid. Harap gunakan file .zip"}, 400

if __name__ == '__main__':
    app.run(debug=True)
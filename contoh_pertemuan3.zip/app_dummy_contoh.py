from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import folium
import geopandas as gpd
import os
from sqlalchemy import create_engine

app = Flask(__name__, template_folder='templates')

# Konfigurasi folder untuk menyimpan file zip sementara
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# ==============================================================================
# PASTE DATABASE_URL SUPABASE ANDA DI BAWAH INI
# Caranya: Buka Dashboard Supabase  --> Project Settings --> Database
# Salin "Connection String" mode "URI", ganti [YOUR-PASSWORD] dengan password Anda
# Contoh: "postgresql://postgres.xxxxx:PASSWORD@aws-0-ap-southeast-1.pooler.supabase.com:5432/postgres"
# ==============================================================================
DATABASE_URL = "ISI_DATABASE_URL_ANDA_DISINI"


def get_db_engine():
    """Membuat koneksi ke PostgreSQL menggunakan SQLAlchemy."""
    if DATABASE_URL == "ISI_DATABASE_URL_ANDA_DISINI":
        raise ValueError("Harap isi variabel DATABASE_URL di dalam file app_dummy.py terlebih dahulu!")
        
    return create_engine(DATABASE_URL)

@app.route('/', methods=['GET'])
def index():
    return render_template('index_dummy.html')

@app.route('/upload', methods=['POST'])
def upload_ke_supabase():
    if 'file_shp' not in request.files:
        return render_template('index_dummy.html', message="Hadeh, file belum dipilih kok sudah di-submit!", success=False)
        
    file = request.files['file_shp']
    
    if file and file.filename.endswith('.zip'):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        try:
            # 1. Baca SHP
            gdf = gpd.read_file(f"zip://{filepath}")
            
            # 2. Samakan CRS (Sangat krusial untuk database)
            if gdf.crs is None:
                gdf.set_crs(epsg=4326, inplace=True)
            elif gdf.crs != "EPSG:4326":
                gdf = gdf.to_crs(epsg=4326)
            
            # 3. KONEKSI KE SUPABASE
            engine = get_db_engine()
            
            # 4. TERBANGKAN KE POSTGIS
            # Ini akan membuatkan tabel secara OTOMATIS jika belum ada.
            gdf.to_postgis(
                name="tabel_praktikum", 
                con=engine, 
                if_exists="replace",  # 'replace' akan menimpa tabel lama kalau ada
                index=False
            )
            
            return render_template('index_dummy.html', message="Berhasil! Data sukses mendarat ke tabel 'tabel_praktikum' di Supabase.", success=True)
            
        except Exception as e:
            return render_template('index_dummy.html', message=f"Gagal push ke Supabase: {str(e)}", success=False)
        finally:
            if os.path.exists(filepath):
                os.remove(filepath)
                
    return render_template('index_dummy.html', message="File harus berupa format .zip!", success=False)

@app.route('/load', methods=['GET'])
def tarik_dari_supabase():
    try:
        engine = get_db_engine()
        
        # AMBIL DARI DATABASE AWAN
        sql_query = "SELECT * FROM tabel_praktikum;"
        gdf = gpd.read_postgis(sql_query, con=engine, geom_col="geometry")
        
        # RENDER PETA FOLIUM
        bounds = gdf.total_bounds
        center_y = (bounds[1] + bounds[3]) / 2.0
        center_x = (bounds[0] + bounds[2]) / 2.0
        
        m = folium.Map(location=[center_y, center_x], zoom_start=12)
        folium.GeoJson(gdf).add_to(m)
        
        m.get_root().width = "100%"
        m.get_root().height = "100%"
        peta_interaktif = m.get_root().render()
        
        return render_template('index_dummy.html', peta_interaktif=peta_interaktif, message="Data sukses ditarik secara real-time dari Supabase!", success=True)
        
    except Exception as e:
        return render_template('index_dummy.html', message=f"Gagal menarik data dari Supabase: {str(e)}", success=False)

if __name__ == '__main__':
    app.run(debug=True, port=5001)
